import express from "express";
import fs from "fs";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());
const port = 5000;
app.listen(port, () => {
	console.log(`Server Running on http://localhost:${port}`);
});

app.get("/api/data", (req, res) => {
	const dataJson = fs.readFileSync("./data.json");
	const data = JSON.parse(dataJson);
	res.send(data);
});

app.post("/api/login", (req, res) => {
	const { username, password } = req.body;
	const userJson = fs.readFileSync("./users.json");
	const users = JSON.parse(userJson);

	const matchedUser = users.find((user) => user.username === username && user.password === password);

	if (matchedUser) {
		// Authentication successful
		res.json({ message: "Login successful", user: matchedUser });
	} else {
		// Authentication failed
		res.status(401).json({ message: "Invalid username or password" });
	}
});
